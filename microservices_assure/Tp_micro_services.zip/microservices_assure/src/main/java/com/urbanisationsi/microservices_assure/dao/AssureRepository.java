package com.urbanisationsi.microservices_assure.dao;

import com.urbanisationsi.microservices_assure.modele.Assure;


public interface AssureRepository extends org.springframework.data.repository.CrudRepository<Assure, Integer> {

}